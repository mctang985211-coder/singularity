import { defineConfig } from 'vitest/config'

/**
 * The R1 driver's own runner: it lives under `packages/singularity/tests/r1/`
 * (untracked, deleted after the evidence is archived) and borrows the
 * repository's TypeScript pipeline through vitest. The generous timeouts are
 * the fixed contract's wall-clock budget, not a convenience: a real model at
 * reasoning effort `high` needs minutes per scenario.
 */
export default defineConfig({
  root: process.cwd(),
  test: {
    include: ['packages/singularity/tests/r1/**/*.spec.ts'],
    environment: 'node',
    hookTimeout: 120_000,
    testTimeout: 900_000,
    fileParallelism: false,
    reporters: ['default'],
  },
})
